package com.search;

public class LinearSearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
