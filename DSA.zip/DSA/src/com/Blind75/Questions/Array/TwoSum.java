package com.Blind75.Questions.Array;

import java.util.HashMap;
//Hashmap
public class TwoSum {

	static int[] twoSum(int input[],int target) {
		
		HashMap<Integer,Integer> map=new HashMap<>();
		for(int i=0;i<input.length;i++) {
			int compliment=target-input[i];
			
			if(map.containsKey(compliment))
			{
				return new int[] {map.get(compliment),i};
			}
			map.put(input[i], i);
		}
		throw new IllegalArgumentException("no match found!");
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int input[]= {3,2,4};
		int target= 6;
		int array[]=twoSum(input,target);
		System.out.println("Array Value:"+array[0]+" "+array[1]);
	}

}
