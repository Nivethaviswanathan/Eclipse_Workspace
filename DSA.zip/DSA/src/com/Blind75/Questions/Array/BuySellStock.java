package com.Blind75.Questions.Array;

public class BuySellStock {
	
	static int buySell(int[] prices) {
		int buyPrice=prices[0];
		int maxProfit=0;
		for(int i=1;i<prices.length;i++) {
			if(prices[i]>buyPrice)
			{
				int profit=prices[i]-buyPrice;
				maxProfit=Math.max(profit, maxProfit);
			}
			else
				buyPrice=prices[i];
				
		}
		return maxProfit;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] input= {7, 1, 5, 3, 6, 4};
		System.out.println("Profit:"+buySell(input));
	}

}
