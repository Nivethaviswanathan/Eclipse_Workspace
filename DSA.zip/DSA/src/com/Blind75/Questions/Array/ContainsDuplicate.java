package com.Blind75.Questions.Array;

import java.util.HashSet;
import java.util.Set;
//Using Hashset
public class ContainsDuplicate {
	
	public static boolean containsDuplicate(int[] nums) {
        Set<Integer> mapstore=new HashSet<>();
        for(int num:nums){
            if(mapstore.contains(num))
            {
                return true;
            }
            else{
                mapstore.add(num);
            }
        }
        return false;
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] num= {1,2,3,1};
		System.out.println("Contains Duplicate:"+containsDuplicate(num));
	}

}
