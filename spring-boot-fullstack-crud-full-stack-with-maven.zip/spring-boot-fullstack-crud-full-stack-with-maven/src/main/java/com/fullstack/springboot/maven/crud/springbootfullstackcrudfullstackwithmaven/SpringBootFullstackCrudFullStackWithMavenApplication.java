package com.fullstack.springboot.maven.crud.springbootfullstackcrudfullstackwithmaven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootFullstackCrudFullStackWithMavenApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootFullstackCrudFullStackWithMavenApplication.class, args);
	}

}
