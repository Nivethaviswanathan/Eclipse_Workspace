package com.fullstack.springboot.maven.crud.springbootfullstackcrudfullstackwithmaven.course;

public class CourseService {

}
