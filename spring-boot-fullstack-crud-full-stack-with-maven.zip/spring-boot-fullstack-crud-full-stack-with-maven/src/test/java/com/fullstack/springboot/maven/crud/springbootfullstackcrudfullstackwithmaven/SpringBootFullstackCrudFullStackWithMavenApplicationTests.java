package com.fullstack.springboot.maven.crud.springbootfullstackcrudfullstackwithmaven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootFullstackCrudFullStackWithMavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
