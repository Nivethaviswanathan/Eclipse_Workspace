package ArrayDS;

//Efficient Approach: The problem can be solved using Dynamic Programming. The idea here is to maintain the count of positive elements and negative elements such that their product is positive. Follow the steps below to solve the problem:
//
//1.Initialize the variable, say res, to store the length of the longest subarray with the positive product.
//2.Initialize two variables, Pos and Neg, to store the length of the current subarray with the positive and negative products respectively.
//3.Iterate over the array.
//4.If arr[i] = 0: Reset the value of Pos and Neg.
//5.If arr[i] > 0: Increment Pos by 1. If at least one element is present in the subarray with the negative product, then increment Neg by 1.
//6.If arr[i] < 0: Swap Pos and Neg and increment the Neg by 1. If at least one element is present in the subarray with the positive product, then increment Pos also.
//7.Update res=max(res, Pos).

//Input: arr[] ={0, 1, -2, -3, -4}
//Output: 3
public class LongSubarray {

	public static int maxSub(int arr[],int n) {
		int res=0,pos=0,neg=0;
		
		for(int i=0;i<n;i++) {
			
			if(arr[i]==0)
			{
				pos=0;neg=0;
			}
			else if(arr[i]>0) {
				pos+=1;
				
				if(neg!=0)
					neg+=1;
				
				res=Math.max(res,pos);
			}
			else {
				//
				pos=pos+neg;
				neg=pos-neg;
				pos=pos-neg;
				
				neg+=1; //1
				
				if(pos!=0)
					pos+=1;
				
				res=Math.max(res,pos);
			}
			
		}
		return res;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	    int arr[] = {-1, -2, -3, 0, 1};
	    int N = arr.length;
	    System.out.println(maxSub(arr,N));
	}

}
