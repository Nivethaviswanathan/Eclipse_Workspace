package ArrayDS;
//Java program to print subarray with sum as given sum
//Time complexity: O(N). If hashing is performed with the help of an array, then this is the time complexity. 
//In case the elements cannot be hashed in an array a hash map can also be used as shown in the above code.
//Auxiliary space: O(N). As a HashMap is needed, this takes linear space.
import java.util.HashMap;

public class LongSubArraySum {
	
	public static void getSubArray(int arr[],int sum,int n) {
		
		int curSum=0;
		int start=0;
		int end=-1;
		HashMap<Integer,Integer> hashmap=new HashMap<>();
		
		for(int i=0;i<n;i++) {
			curSum=curSum+arr[i];
			
			if(curSum-sum==0){
				start=0;
				end=i;
				break;
			}
			
			if(hashmap.containsKey(curSum-sum)) {
				start=hashmap.get(curSum-sum)+1;
				end=i;
				break;
			}
			
			hashmap.put(curSum, i);
		}
        if (end == -1) {
            System.out.println(
                "No subarray with given sum exists");
        }
        else {
            System.out.println("Sum found between indexes "
                               + start + " to " + end);
        }
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//        int[] arr = { 10, 2, -2, -20, 10 };
		int arr[] = { 15, 2, 4, 8, 9, 5, 10, 23 };
        int n = arr.length;
//        int sum = -10;
        int sum=23;
        getSubArray(arr,sum,n);
	}

}
