
public class MyAdd<T>{
	
	void add(T t) {
		System.out.println(t);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyAdd<Number> myadd=new MyAdd<>();
		myadd.add(new Integer(1));
		myadd.add(new Double(1.0));
	}

}
