import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.LongStream;
import java.util.stream.Stream;

public class Apexon {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr={1,0,2,0,1,2,0} ;
		List<Integer> data=new ArrayList<>();
		data.add(1);
		data.add(1);
		data.add(1);
		data.add(1);
		data.add(1);
		data.add(1);
		String str=Arrays.toString(arr);
		
		HashMap<Integer,String> test=new HashMap<>();
		//System.out.println(str);
		//Stream<Integer> data1=
				str.chars().distinct().forEach(System.out::println);
		
//		List<Integer> personsWithoutDuplicates = data.stream()
//				 .distinct()
//				 .collect(Collectors.toList());
		//data.stream().forEach(System.out::println);
		

	}

}
