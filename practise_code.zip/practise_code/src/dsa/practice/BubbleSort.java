package dsa.practice;

public class BubbleSort {
	
	static void bubbleSort(int input[]) {
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {64, 34, 25, 12, 22, 11, 90};
		BubbleSort.bubbleSort(arr);
	}

}
