package dsa.practice;

/*Binary search is one of the searching techniques applied 
when the input is sorted as here we are focusing on finding 
the middle element that acts as a reference frame whether 
to go left or right to it as the elements are already sorted*/

public class BinarySearch {
	
	static int binarySearch(int input[],int num) {
		
		int i=0;
		int j=input.length-1;
		while(i<=j) {
			
			int mid=(i+j)/2;
			
			if(num==input[mid])
				return mid;
			
			if(num>input[mid])
				i=mid+1;
			else
				j=mid-1;
		}
		return -1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Input
        int[] arr = {2, 3, 4, 10, 40};
        int x = 11;
        int result=BinarySearch.binarySearch(arr, x);
        System.out.println(result);
	}

}
