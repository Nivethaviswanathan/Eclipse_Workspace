
class vuram {
//	input: 11,13,12,16,13,18,23,26,28
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] input= {11,13,12,16,13,18,23,26,28};
		
		for(int i=0;i<input.length;i++)
		{
			for(int j=1;j<)
			{
				if()
			}
		}
	}

}
