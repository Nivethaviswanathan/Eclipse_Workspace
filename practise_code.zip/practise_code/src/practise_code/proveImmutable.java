package practise_code;

public class proveImmutable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	    String first = "CATCAT";
	    first=first.replace('A', 'Z');
	    first.concat("first");
	    System.out.println("First = " + first);
//	    System.out.println("Second = " + second);
	}

}
