package practise_code;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.PriorityQueue;

public class Person {

	private String firstName;
	private String lastName;
	
	public Person(String string, String string2) {
		// TODO Auto-generated constructor stub
		this.firstName=string;
		this.lastName=string2;
		
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Person p1=new Person("firstName1","lastName1");
//		Person p2=new Person("firstName2","lastName2");
//		
//		List<Person> list=new ArrayList<>();
//		list.add(p1);
//		list.add(p2);
//		Iterator itr=list.iterator();
//		
//		while(itr.hasNext()) {
//			
//			System.out.println(itr.next());
//			list.add(new Person("firstname3","lastname3"));
//		}
		
		PriorityQueue<String> ptr=new PriorityQueue<String>();
		ptr.add("carrot");
		ptr.add("apple");
		ptr.add("banana");
		System.out.println(ptr.poll()+":"+ptr.peek());
		
	}

}
