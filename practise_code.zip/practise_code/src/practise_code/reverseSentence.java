package practise_code;

public class reverseSentence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
