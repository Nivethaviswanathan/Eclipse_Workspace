package practise_code;

import java.util.Iterator;
import java.util.TreeSet;

public class Drink {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		decreaseNumberByOne(2);
	}
	
	public static void decreaseNumberByOne(int num) 
	{
		if(num>=0)
		{
			decreaseNumberByOne(num-1);
		}
		System.out.println("Number:"+num);
	}
	

}
