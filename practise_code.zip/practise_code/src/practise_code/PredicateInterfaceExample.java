package practise_code;

import java.util.function.Predicate;
public class PredicateInterfaceExample {
    public static void main(String[] args)
    {
        // Creating predicate
        Predicate<Integer> lesserthan = i -> (i < 18); 
  
        // Calling Predicate method
        System.out.println(lesserthan.test(18)); 
    }
}
