package practise_code;
import java.util.*;

public class JPMorgan implements interface1,Comparable<JPMorgan>{
	
	  @Override
	  public boolean equals(Object o) {
	    if (this == o) return true;
	    if (o == null || getClass() != o.getClass()) return false;
	    JPMorgan mapKey = (JPMorgan) o;
	    return Objects.equals(data, mapKey.data);
	  }

	  @Override
	  public int hashCode() {
	    return Objects.hash(data);
	  }
	  
	    @Override
	    public int compareTo(JPMorgan employee) {
	        return (int)(this.hashCode() - employee.hashCode());
	    }
	
	public void test() {
		System.out.println("test");
	}
	
	static void testValue() {
		System.out.println("testValue");
	}
	
	int data=12;
	int data1=13;
	
	public JPMorgan(int num) {
		this.data=num;
		
	}
	
	static int num=10;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int word;
		int data=100;
		int data1=195;
		int data2=350;
		int data3=10;
		JPMorgan jp=new JPMorgan(1000);	
		JPMorgan jp1=new JPMorgan(195);	//data=100
		JPMorgan jp2=new JPMorgan(350);	//data=195
		JPMorgan jp3=new JPMorgan(490);	//data=350
		
		int printData=jp.data;
		System.out.println(printData);
//		System.out.println(jp1.data);
//		System.out.println(jp2.data);
//		System.out.println(jp3.data);
		jp1.num=100;
//		System.out.println(jp1.num);
//		System.out.println(jp2.num);
//		System.out.println(jp3.num);
		
		HashMap<JPMorgan,String> map=new HashMap<JPMorgan,String>();
		map.put(jp, "Nivetha");
		map.put(jp1, "Nivetha1");
		map.put(jp2, "Chetan");
		map.put(jp3, "Chetan1");
		
        TreeMap<JPMorgan, String> tree_map
        = new TreeMap<JPMorgan, String>(map);
		
//		for(Map.Entry<JPMorgan, String> resultMap: tree_map.entrySet()) 
//		{
//			System.out.println("key:"+resultMap.getKey().hashCode()+" Value:"+resultMap.getValue());
//		}
		
		jp.test();
		JPMorgan.testValue();
		
		//sort by key, we use the comparingByKey comparator java 8
		map.entrySet()
		  .stream()
		  .sorted(Map.Entry.<JPMorgan,String>comparingByKey())
		  .forEach(System.out::println);
		
		
		//by value
		map.entrySet()
		.stream()
		.sorted(Map.Entry.<JPMorgan,String>comparingByValue())
		.forEach(System.out::println);
	
	}

}

