package practise_code;

public class reverseWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String input="My name is fattoo";
		String str[]=input.split("\\s");
		String reverseWord="";
		for(String s:str) {
			StringBuilder sb=new StringBuilder(s);
			sb.reverse();
			reverseWord+=sb.toString()+" ";
		}
		System.out.println(reverseWord);
		
				
	}

}
