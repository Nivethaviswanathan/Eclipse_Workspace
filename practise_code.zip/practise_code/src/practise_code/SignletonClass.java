package practise_code;

public class SignletonClass {

	//global variable
	private static SignletonClass singleInstance=null;
	
	//private constructor
	private SignletonClass() {
		
	}
	
	//public method
	public static SignletonClass getInstance() {
		
		if(singleInstance==null)
			singleInstance=new SignletonClass();
		
		return singleInstance;
	}
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SignletonClass x=SignletonClass.getInstance();
		SignletonClass y=SignletonClass.getInstance();
		SignletonClass z=SignletonClass.getInstance();
		
		System.out.println("X:"+x.hashCode());
		System.out.println("Y:"+y.hashCode());
		System.out.println("Z:"+z.hashCode());
	}

}
