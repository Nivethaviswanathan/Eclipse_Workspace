package practise_code;

public class Super{
	   public static void sample(){
	      System.out.println("Method of the superclass");
	   }
	}
