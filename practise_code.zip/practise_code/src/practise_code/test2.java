package practise_code;

public class test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("1 ");
		synchronized(args) {
			System.out.print("2 ");
			try
			{
				args.wait();
			}
			catch(InterruptedException e)
			{
				
			}
		}
		System.out.print("3 ");
	}

}
