package practise_code;


	public class OverridingExample extends Super {
	   public static void sample(){
	      System.out.println("Method of the subclass");
	   }
	   public static void main(String args[]){
	      Super obj1 = (Super) new OverridingExample();
	      OverridingExample obj2 = new OverridingExample();
	      Super obj3= new OverridingExample();
	      obj1.sample();
	      obj2.sample();
	      obj3.sample();
	   }
	}
