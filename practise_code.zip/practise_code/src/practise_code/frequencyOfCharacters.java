package practise_code;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

public class frequencyOfCharacters {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> input=new ArrayList<>();
		input.add("a");
		input.add("a");
		input.add("b");
		input.add("a");
		input.add("b");
		input.add("a");
		
		ConcurrentHashMap<String,Integer> mp=new ConcurrentHashMap<String,Integer>();
		for(String lp:input)
		{
			if(mp.containsKey(lp))
				mp.put(lp,mp.get(lp)+1);
			else
				mp.put(lp, 1);
		}
		for(Map.Entry<String,Integer> print:mp.entrySet())
		{
			System.out.println("key: "+print.getKey()+"value: "+print.getValue());
			if(print.getValue()>2)
				mp.remove(print.getKey());
		}
		for(Map.Entry<String,Integer> print:mp.entrySet())
		{
			System.out.println("key: "+print.getKey()+"value: "+print.getValue());
		}
		
	}

}
