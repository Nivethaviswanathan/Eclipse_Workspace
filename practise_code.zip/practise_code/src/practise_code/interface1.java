package practise_code;

public interface interface1{
	
	default void defaultMethod() {
		System.out.println("defaultMethod");
	}
}
