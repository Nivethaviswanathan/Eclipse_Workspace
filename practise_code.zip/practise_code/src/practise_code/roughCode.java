package practise_code;

public class roughCode {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="nivetha";
		str="poornima";
		System.out.println(str);
		
	}

}
