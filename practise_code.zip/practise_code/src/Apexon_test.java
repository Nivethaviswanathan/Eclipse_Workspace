
public class Apexon_test {

	private static Apexon_test singleInstance=null; 
	
	private Apexon_test(){
		
	}
	
	private static Apexon_test generateInstance(){
		if(singleInstance==null)
			singleInstance=new Apexon_test();
		
		return singleInstance;
	}


	public static void main(String args[]){
		Apexon_test data=Apexon_test.generateInstance();
		Apexon_test data1=Apexon_test.generateInstance();
		System.out.println(data.hashCode());
		System.out.println(data1.hashCode());
	}

}



//2 2000 
//2 2500 ->   