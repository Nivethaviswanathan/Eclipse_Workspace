package EasyLevel;

import java.util.TreeMap;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
//sort by both key and value using java 8
public class SortByBothJAVA8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer,String> treeMap=new HashMap<Integer,String>();
		treeMap.put(23, "Yash");  
		treeMap.put(17, "Arun");  
		treeMap.put(15, "Swarit");  
		treeMap.put(9, "Neelesh");  
		//sort by key, we use the comparingByKey comparator java 8
		treeMap.entrySet()
		  .stream()
		  .sorted(Map.Entry.<Integer,String>comparingByKey())
		  .forEach(System.out::println);
		
		//by value
		treeMap.entrySet()
		.stream()
		.sorted(Map.Entry.<Integer,String>comparingByValue())
		.forEach(System.out::println);
		
		treeMap.entrySet().stream().sorted(Map.Entry.<Integer,String>comparingByKey()).forEach(System.out::println);
		treeMap.entrySet().stream().sorted(Map.Entry.<Integer,String>comparingByValue()).forEach(System.out::println);
	}

}
