package EasyLevel;

import java.util.Map.Entry;
import java.util.TreeMap;

public class SortByKey {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeMap<Integer,String> treeMap=new TreeMap<Integer,String>();
		treeMap.put(23, "Yash");  
		treeMap.put(17, "Arun");  
		treeMap.put(15, "Swarit");  
		treeMap.put(9, "Neelesh");  
		
		for(Entry<Integer, String> data:treeMap.entrySet()) {
			System.out.println("Key:"+data.getKey()+"Valuue:"+data.getValue());
		}
	}

}
