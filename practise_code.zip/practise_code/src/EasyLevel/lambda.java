package EasyLevel;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

class Student{
	int rollNo;
	String name;
 
	public Student(int rollNo, String name){
		super();  
        this.rollNo = rollNo;  
        this.name = name;  
	}
}

public class lambda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Student> list=new ArrayList<Student>();
        list.add(new Student(1,"Nidhi"));  
        list.add(new Student(3,"Parbhjot"));  
        list.add(new Student(2,"Amani")); 
		
		list.stream().filter(data ->data.rollNo >2).forEach((n)-> System.out.println(n.name));
		
		list.stream().filter(n->n.rollNo > 0).forEach(data->System.out.println(data.name));
		
	}

}
