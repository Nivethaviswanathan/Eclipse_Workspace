package EasyLevel;

public class SortByValues {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
