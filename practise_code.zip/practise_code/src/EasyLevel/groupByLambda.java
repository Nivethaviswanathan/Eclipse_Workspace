package EasyLevel;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class groupByLambda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list=Arrays.asList("geeks","for","geeks");
		
		Map<String,Long> mp=list.stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		System.out.println(mp);
		
		Map<String,Long> practs=list.stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		System.out.println(practs);
	}

}
