
public class IDEAS2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name="Nivetha";

		String result="";

		for(int i=name.length()-1;i>=0;i++)
		{
			result=result+name.charAt(i);
		}

		System.out.println(result);
	}

}
