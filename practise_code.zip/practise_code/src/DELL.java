import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import DS.LinkedList;

public class DELL {

	
	//XXXFFFFFFAAAXX -> X3F6A3X2
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String input="XXXFFFFFFAAAXX"; //13
		int j=0;
		int count=1;
		StringBuilder sb=new StringBuilder();
		List<String> data=new ArrayList<>();
		for(int i=0;i<input.length()-1;i++) {
			if(i==input.length()-2) {
				System.out.print(input.charAt(i)+""+count);
				
			}
			if(input.charAt(i)==input.charAt(i+1))
			{
				count+=1;
			}
			else {
				System.out.print(input.charAt(i)+""+count);
				count=1;
			}
		}
		System.out.println(sb.toString());
//		char[] ch=input.toCharArray();
//		HashMap<Character,Integer> result=new HashMap<Character,Integer>();
//		
//		for(int i=0;i<ch.length;i++)
//		{
//			if(result.get(ch[i])!=null)
//			{
//				result.put(ch[i],result.get(ch[i])+1);
//			}
//			else {
//				result.put(ch[i],1);
//			}
//		}
//		
//		for(Map.Entry<Character,Integer> result1: result.entrySet())
//		{
//			System.out.println("key"+result1.getKey()+"value"+result1.getValue());
//		}
		
	}

}
