package MediumLevel;

//MOVING ZEROS TO END OF ARRAY

//Time Complexity: O(n) where n is number of elements in input array.
//Auxiliary Space: O(1)

//Input :  arr[] = {1, 2, 0, 4, 3, 0, 5, 0};
//Output : arr[] = {1, 2, 4, 3, 5, 0, 0};
//
//Input : arr[]  = {1, 2, 0, 0, 0, 3, 6};
//Output : arr[] = {1, 2, 3, 6, 0, 0, 0};


public class ZerosEOArray {
	
	static void pushZeros(int arr[],int n) {
		
		int count=0;
		for(int i=0;i<n;i++) {
			if(arr[i]!=0)
				arr[count++]=arr[i];
		}
		
		while(count<n)
			arr[count++]=0;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {1, 9, 8, 4, 0, 0, 2, 7, 0, 6, 0, 9};
		int n=arr.length;
		pushZeros(arr,n);
		for(int num:arr)
		{
			System.out.print(num);
		}
		
	}

}
