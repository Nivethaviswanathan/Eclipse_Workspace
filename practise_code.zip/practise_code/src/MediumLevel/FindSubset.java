package MediumLevel;

import java.util.ArrayList;
import java.util.Collections;

public class FindSubset {
	
	public void displaySubset(int arrsize,ArrayList<Integer> inputarr) {
		
		ArrayList<Integer> temp=new ArrayList<>();
		
		ArrayList<ArrayList<Integer>> result=new ArrayList<>();
		
		getSubset(0,temp,result,inputarr);
		
		// Printing the final answer  
		for (int i = 0; i < result.size(); i++)   
		{  
		// Sorting and printing each subset  
		Collections.sort(result.get(i));  
		System.out.print("[ ");  
		for (int j = 0; j < result.get(i).size(); j++)   
		{  
		System.out.print(result.get(i).get(j) + " ");  
		}  
		System.out.print("]");  
		System.out.println( );  
		}  
	}
	
	public void getSubset(int i,ArrayList<Integer> temp,ArrayList<ArrayList<Integer>> result,ArrayList<Integer> inputarr) {
		
		if(i==inputarr.size())
		{
			if(temp.size()>0)
				result.add(temp);
			return;
		}
		
		ArrayList<Integer> temp1=new ArrayList<>(temp);
		temp1.add(inputarr.get(i));
		getSubset(i+1,temp1,result,inputarr);
		getSubset(i + 1, temp, result, inputarr);  
			
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FindSubset fs=new FindSubset();
		ArrayList<Integer> inputarr=new ArrayList<>();//[4,1,2,3,1,5]   
		inputarr.add(1);
		inputarr.add(2);
		inputarr.add(3);
		
		fs.displaySubset(inputarr.size(),inputarr);

	}

}
