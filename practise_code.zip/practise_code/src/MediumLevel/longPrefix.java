package MediumLevel;

//Java Program to find the longest common prefix

class longPrefix {
//divide and conquer
//	Time Complexity: O(K) where K is the sum of all the characters in all strings.
//	Space Complexity: O(M log N), as there are log N recursive calls and each needs a space of M.
//A Utility Function to find the common prefix between
//strings- str1 and str2
    static String compareUtilis(String s1,String s2)
    {
        int n1=s1.length(),n2=s2.length();
        String resultUtil="";
        for(int i=0,j=0;i<=n1-1 && j<=n2-1;i++,j++)
        {
            if(s1.charAt(i)!=s2.charAt(j))
            break;
            resultUtil+=s1.charAt(i);
            System.out.println(resultUtil);
        }
        return resultUtil;
    }
    
    static String commonPrefix(String arr[],int low,int high)
    {
        if(low==high)
            return arr[low];
            
        if(high>low)
        {
            int mid=low + (high-low) /2;
            
            String s1=commonPrefix(arr,low,mid);
            System.out.println(s1);
            String s2=commonPrefix(arr,mid+1,high);
            System.out.println(s2);
            return compareUtilis(s1,s2);
        }
        return null;
    }
//Driver program to test above function
	public static void main(String[] args) {
		String arr[] = {"d", "d",
			"d", "d"};
		int n = arr.length;

		String ans = commonPrefix(arr, 0, n - 1);

		if (ans.length() != 0) {
			System.out.println("The longest common prefix is "
					+ ans);
		} else {
			System.out.println("There is no common prefix");
		}
	}
}
/* This JAVA code is contributed by 29AjayKumar*/

