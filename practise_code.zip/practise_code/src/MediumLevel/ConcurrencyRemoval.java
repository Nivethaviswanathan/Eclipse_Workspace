package MediumLevel;

import java.util.Arrays;
//Time Complexity : O(n) 
//Auxiliary Space : O(1)
public class ConcurrencyRemoval {

	static void removeConcurrent(char s1[])
	{
		int n=s1.length;
		int j=0;
		if(n<2)
			return ;
		
		
		for(int i=1;i<n;i++)
		{
			if(!Character.toString(s1[j]).equalsIgnoreCase(Character.toString(s1[i])))
			{
				j++;
				s1[j]=s1[i];
			}
		}
		System.out.println(Arrays.copyOfRange(s1, 0, j+1));
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="aaabBCcdaa";
		String str1=str.toLowerCase();
		char s1[]=str.toCharArray();
		
		removeConcurrent(s1);
	}

}
