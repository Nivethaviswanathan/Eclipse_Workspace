package MediumLevel;

import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class streamsjava {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}

}
