
public class IDEAS {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name="Nivetha";

				StringBuilder sb=new StringBuilder();

				for(int i=name.length()-1;i>=0;i++)
				{
					sb.append(name.charAt(i));
				}

				System.out.println(sb.toString());
	}

}
