
public class testtt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String input="developers";
		char[] updateinput=input.toCharArray();
//		int i=0;
		int length= input.length(); //9
		int j=length-1; //8
		if(length%2==0)
			length=length/2; //4
		else
			length=(length/2)+1; //5
		
		for(int i=0;i<=length-1;i++) {
			char first=input.charAt(i);
			char last=input.charAt(j);
			updateinput[i]=last;
			updateinput[j]=first;
			j--;
		}
		
		System.out.println(updateinput);
	}

}
