package Microsoft;
import java.util.HashMap;

public class RemoveDuplicateString {
	
	static String removeDuplicate(String input,int length) {
		String result="";
		char[] inputChar=input.toCharArray();
		HashMap<Character,Integer> map=new HashMap<>();
		for(int i=0;i<length;i++) {
			
			if(!map.containsKey(inputChar[i])) {
				result+=inputChar[i];
				map.put(inputChar[i], 1);
			}
		}
		return result;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String input="HappyNewYear";
		System.out.println(removeDuplicate(input,input.length()));

	}

}
