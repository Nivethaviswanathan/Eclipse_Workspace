package paypal;

public class GFG {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//A[] ={2,2,1,7,5,3} N=4
		
		
		
	}

}
