import java.util.ArrayList;
import java.util.List;

//Input : List of Numbers => 1, 2, 3, 4
// 
//Step 1: Square them => 1, 4, 9, 16
// 
//Step 2: Find odd => 1, 9
// 
//Step 3: Sum => 1 + 9
// 
//Step 4: Print 10


public class TCS_Code {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> input=new ArrayList<>();
		input.add(1);
		input.add(2);
		input.add(3);
		input.add(4);
		
		input.stream().
		filter(x->x%2!=0).map(data -> data*data).forEach(number->System.out.println(number));
//		int sqr[]=new int[input.length]; {1, 2, 3, 4};
//		int result=0;
//		
//		for(int i=0;i<input.length;i++)
//		{
//			sqr[i]=input[i]*input[i];
//			if(sqr[i]%2!=0)
//				result=result+sqr[i];
//		}
//		System.out.println("Input Value"+result);
		
		
		
	}

}
