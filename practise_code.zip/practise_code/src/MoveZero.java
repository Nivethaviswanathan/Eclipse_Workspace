import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class MoveZero {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count=0;
		int[] arr={1,0,2,0,1,2,0} ;
		int[] result=new int[arr.length];
//		List<Integer> data=new LinkedList<>();
//		for(int num:arr) {
//			if(num!=0)
//				data.add(num);
//			else
//				count++;
//		}
//		for(int i=0;i<count;i++) {
//			data.add(0);
//		}
//		
//		for(int result:data) {
//			System.out.println(result);
//		}
		int i=0;
		for(int num:arr) {
			
			if(num!=0)
				result[i]=num;
			else
				count++;
			i++;
		}
		int n=arr.length-count;
		for(int j=n+1;j<result.length;j++) {
			result[j]=0;
		}
		for(int num:result) {
			System.out.println(num);
		}
		
	}

}
