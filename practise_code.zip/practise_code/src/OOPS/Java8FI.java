package OOPS;

public class Java8FI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
