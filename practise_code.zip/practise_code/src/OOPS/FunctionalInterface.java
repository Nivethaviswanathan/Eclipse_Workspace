package OOPS;

public interface FunctionalInterface {

}
