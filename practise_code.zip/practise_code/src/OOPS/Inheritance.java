package OOPS;

import java.io.IOException;

class SuperClass{
	
	int data;
	private int checkPrivate;
	static int checkStatic;
	
	public void displaySuper() {
		System.out.println("SuperClassDisplaySub");
	}
	
	public void display(String data){
		System.out.println("Superclass");
	}
	
	private void displayPrivate(){
		System.out.println("SuperclassPrivate");
	}
	
	static void displayStatic() {
		System.out.println("SuperclassStatic");
	}
}

class SubClass extends SuperClass{
	public void display(String test) throws RuntimeException{
		System.out.println("Subclass");
	}
	
	private void displayPrivate(){
		System.out.println("SubclassPrivate");
	}
	
	static void displayStatic() {
		System.out.println("SubclassStatic");
	}
	
	public void displaySub() {
		System.out.println("SubClassDisplaySub");
	}
}

public class Inheritance {

	private void displayPrivate(){
		System.out.println("InheritancePrivate");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SuperClass sc=new SuperClass();
		SuperClass sc1=new SubClass();
		SubClass sc2=new SubClass();
//		sc1.displaySuper(); //SuperClassDisplaySub
//		sc.display();//superclass
//		sc1.display("test");//Subclass
//		sc1.displayStatic();//SuperclassStatic
//		sc.displayStatic(); //SuperclassStatic
//		sc1.displaySub(); //undefined compile time exception
		sc2.displayStatic();
	}

}
