import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		    Input:     ieerieri
//		    Output:     ieereri
		
		String str="ieerieri";
		char[] result=new char[str.length()];
		int j=0;
		for(int i=0;i<str.length();i++){
			if(i!=0 && i!=str.length()-1)
			{
				if(str.charAt(i)!='i')
				{
					result[j]=str.charAt(i);
					j++;
				}
				
			}
			else {
				result[j]=str.charAt(i);
				j++;
			}
		}
		
		for(char data:result) {
			System.out.print(data);
		}
		
		}

}
