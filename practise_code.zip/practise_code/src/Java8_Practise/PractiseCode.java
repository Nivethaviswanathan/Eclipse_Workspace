package Java8_Practise;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PractiseCode {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] nums = {"three","two","one"};
		Arrays.stream(nums).forEach(num -> System.out.println(num));
		Arrays.stream(nums).forEach(System.out::println);
		List<Integer> data=new ArrayList<>();
		data.add(1);
		data.add(1);
		data.add(1);
		data.add(1);
		data.add(1);
		data.add(1);
		data.stream().forEach(x->System.out.println(x));
		data.stream().forEach(data1->System.out.println(data1));
	}

}
