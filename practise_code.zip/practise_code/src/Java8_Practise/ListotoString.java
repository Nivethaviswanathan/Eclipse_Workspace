package Java8_Practise;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ListotoString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				
			// creating a list with strings.
			List<String> list =  Arrays.asList("One",
							  "Two",
							  "Three",
							  "Four",
							  "Five");

			// using java 8 Collectors.joining with delimiter, prefix and suffix
//			String joiningString = list.map().stream().collect(Collectors.joining());
			
			// printing
//			System.out.println("Collectors.joining string : "+joiningString);
			
			String joiningString3 = list.stream().collect(Collectors.joining("", "", ""));
			
			// printing
			System.out.println("Collectors.joining string with @ separator : "+joiningString3);

	}

}
