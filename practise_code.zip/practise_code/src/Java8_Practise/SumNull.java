package Java8_Practise;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class SumNull {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> numbers = Arrays.asList(1, null, 3, 4, 5, 6, null, 8, 9, 10);
		int total=numbers.stream().filter(x->x!=null).reduce(0,(num1,num2)->num1+num2);
		System.out.println(total);
	}

}
