package Java8_Practise;

import java.time.LocalTime;
import java.util.Arrays;
import java.util.Comparator;

public class FindLargest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int[] numbers = {5, 9, 11, 2, 8, 21, 1};
        
        
        // print to console
        System.out.println("Numbers in an Arrays : "
                + Arrays.toString(numbers));
 
 
        // Execution - start time
        LocalTime startTime = LocalTime.now();
 
 
        // sort in descending-order and get 2nd largest element
        int secondLargestNumber = Arrays
                .stream(numbers)
                .boxed() // to Convert primitive integers into Integer objects using Stream.boxed() method
                .sorted(Comparator.reverseOrder())
                .skip(2)//We will skip first number which is the largest number using Stream.skip() method
                .findFirst()//Stream.findFirst() method will get fist element will return 2nd largest number in the Arrays
                .get();
        System.out.println("\nSecond largest number in an Arrays is - "
                + secondLargestNumber);
	}

}
