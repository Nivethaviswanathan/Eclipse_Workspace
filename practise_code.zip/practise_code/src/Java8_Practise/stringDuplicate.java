package Java8_Practise;

public class stringDuplicate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="Nivethann m";
		
		long result=str.chars().distinct().count();
		System.out.println(result);
		
		
	}

}
